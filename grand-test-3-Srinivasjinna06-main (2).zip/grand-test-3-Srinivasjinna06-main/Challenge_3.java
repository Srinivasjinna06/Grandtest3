import java.util.*;

class Publication
{
  String title;
  double price;
  int copies;
  Publication(String title,double price,int copies)
  {
    this.title=title;
    this.price=price;
    this.copies=copies;
  }
}
class Book extends Publication
{
  String author;
  Book(String title,double price,int copies,String author)
  {
   super(title,price,copies);
   this.author=author;
  }
}
class Magazine extends Publication
  {
    int OrderQty;
    String currentissues;
    Magazine(String title,double price,int copies,int OrderQty,String currentissues)
    {
      super(title,price,copies);
      this.OrderQty=OrderQty;
      this.currentissues=currentissues;
    }
  }

public class Challenge_3
  {
    public static void main(String[] args)
    {
      Scanner s=new Scanner(System.in);
      
      System.out.println("Enter the title: ");
      String title=s.nextLine();
      System.out.println("Enter the price: ");
      double price=s.nextDouble();
      System.out.println("Enter the copies sold: ");
      int soldQty=s.nextInt();
      System.out.println("Enter the copies order: ");
      int OrderQty=s.nextInt();
      
      Book b=new Book(title,price,soldQty,"unknown author");
      Magazine m=new Magazine(title,price,soldQty,OrderQty,"currentIssues");
      
      int totalorder=soldQty+OrderQty; 
      double totalsales=soldQty*price;

      System.out.println("total no.of copies of book orders is  "+totalorder);
      System.out.println("total sale of publications is "+totalsales);
      
    }
  }