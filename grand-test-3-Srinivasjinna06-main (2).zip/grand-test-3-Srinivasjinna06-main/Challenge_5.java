import java.util.*;
class Bank
{
  String accountholder_name;
  long balance;
  Scanner s=new Scanner(System.in);

  void creatAccount()
  {
    System.out.println("Enter the account holder name: ");
    accountholder_name=s.nextLine();
    System.out.println("Enter the intial balance: ");
    balance=s.nextLong();
  }
}
class Account extends Bank
  {
    long deposit;
    long withdraw;
    long total_balance;

    void deposit()
    {
      System.out.println("enter the amount to be deposited: ");
      deposit=s.nextLong();
    }
    void totalbalance()
    {
      total_balance=balance+deposit;
      System.out.println("Your total balance is "+total_balance);
    }
    void withdraw()
    {
      System.out.println("Enter amount to with draw: ");
      withdraw=s.nextLong();
    }
    void checkbalance()
    {
      System.out.println("Your total baance is "+(total_balance-withdraw));
    }
    void display()
    {
      System.out.println("Account holder name is "+accountholder_name);
      System.out.println("Balance is "+balance);
      System.out.println("deposite is "+deposit);
      System.out.println("withdrawl is "+withdraw);
      System.out.println("The total  balance is "+balance);
    }
  }
public class Challenge_5
  {
    public static void main(String[] args)
    {
      while(true){
      System.out.println("Please check the operations: ");
      Scanner s=new Scanner(System.in);
      System.out.println("enter the options shown below: ");
      System.out.println("1.create account: ");
      System.out.println("2.deposit account: ");
      System.out.println("3.withdraw account: ");
      System.out.println("4.check account: ");
      System.out.println("5.display account: ");
      System.out.println("6.exit  program: ");
      Account n=new Account();
      System.out.println("Enter the option: ");
      int option=s.nextInt();

      switch(option)
        {
          case 1:n.creatAccount();
            break;
          case 2:n.deposit();
            break;
          case 3:n.withdraw();
            break;
          case 4:n.checkbalance();
            break;
          case 5:n.display();
            break;
          default:
            System.out.println("exit");
        }
      }
    }
  }