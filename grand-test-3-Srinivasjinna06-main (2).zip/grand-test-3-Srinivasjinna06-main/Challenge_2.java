import java.util.*;
public class Challenge_2
{
  public static void main(String[] args)
  {
    Scanner s=new Scanner(System.in);
    System.out.println("Enter the array size: ");
    int n=s.nextInt();
    int arr[]=new int[n];
    System.out.println("Enter the elements in array: ");
    for(int i=0;i<n;i++)
      {
        arr[i]=s.nextInt();
      }
    int evencount=0;
    int oddcount=0;
    int primecount=0;
    int palindromecount=0;
    for(int i=0;i<n;i++)
      {
        if(arr[i]%2==0)
        {
          evencount++;
        }
        if(arr[i]%2!=0)
        {
          oddcount++;
        }
        boolean isprime=true;
        if(arr[i]<2 && arr[i]==0 && arr[i]==1)
        {
          System.out.println(arr[i]+" It's not a prime");
          isprime=false;
        }
        else
        {
          for(int j=2;j<n;j++)
            {
              if(arr[i]%j==0)
              {
                isprime=false;
                break;
              }
            }
        }
        if(isprime)
        {
          primecount++;
        }
        int temp=arr[0];
        int rev=0;
        while(temp!=0)
          {
            int rem=temp%10;
            rev=rem+rev*10;
            temp/=10;  
          }
        if(arr[i]==rev)
        {
          palindromecount++; 
        }   
      }
    System.out.println("even count is "+evencount);
    System.out.println("odd count is "+oddcount);
    System.out.println("prime count is "+primecount);
    System.out.println("palindrome count is "+palindromecount);
    
  }
}