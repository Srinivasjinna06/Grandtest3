import java.util.*;
class Employee
{
  String name;
  int id;
  String address;
  String email;
  long ph_num;
  long salary;
  double grass;
  Scanner s=new Scanner(System.in);  
}
class employers extends Employee
  {
    void details()
    {
      System.out.println("Enter the name of employee: ");
      String name=s.nextLine();
      System.out.println("Enter the id of employee: ");
      int id=s.nextInt();
      System.out.println("Enter the Address of employee: ");
      String address=s.nextLine();
      System.out.println("Enter the email id of employee: ");
      String email=s.nextLine();
      System.out.println("Enter the phone number of employee: ");
      long ph_num=s.nextLong();
     System.out.println("Enter the salary of employee: ");
      long salary=s.nextLong();
    }
      void play_slip()
      {
        double HRA,DA,PF,staffclub;
        HRA=salary*(10/100);
        DA=salary*(97/100);
        PF=salary*(12/100);
        staffclub=salary*(0.1/100);
        grass=salary+HRA+DA+PF;
        System.out.println("HRA is "+HRA);
        System.out.println("DA is "+DA);
        System.out.println("PF is "+PF);
        System.out.println("Staff club fund is "+staffclub);
        System.out.println("The total Gross pay slip os empoyee is "+grass);
      }
  }

    public class Challenge_4
      {
        public static void main(String[] args)
        {
          employers e=new employers();
          e.details();
          e.play_slip();
        }
      }
      
  
